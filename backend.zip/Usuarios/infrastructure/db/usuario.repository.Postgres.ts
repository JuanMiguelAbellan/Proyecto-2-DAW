import executeQuery from "../../../context/db/postgres.connector";
import Usuario from "../../domain/Usuario";
import UsuarioRepository from "../../domain/usuario.repository";
import Mensaje from "../../../Ollama/domain/Mensaje"

export default class UsuarioRepositoryPostgres implements UsuarioRepository{
    getHistorial(idUsuario: Number, idChat: Number): Promise<[{}]> {
        throw new Error("Method not implemented.");
    }
    async getChats(idUsuario: Number): Promise<any> {
        const query = `SELECT * FROM chats WHERE id_usuario = ${idUsuario} ORDER BY creado_en DESC`;
        const result: any[] = await executeQuery(query);
        return result || [];
        
    }
    async getUsuario(idUsuario: Number): Promise<Usuario> {
        const query = `SELECT u.*, s.plan FROM usuarios u
        LEFT JOIN subscripcion s ON u.id_usuario = s.id_usuario
        WHERE u.id_usuario = ${idUsuario}`
        const result: any[] = await executeQuery(query);
        if (result.length === 0) return null;
        const user = result[0];
        return {
            id: user.id_usuario,
            email: user.email,
            password: user.password_hash,
            nombre: user.nombre,
            apellidos: user.apellidos,
            rol: user.rol,
            preferencias: user.preferencias,
            planSubscripcion: user.plan || 'gratis'
        };
    }

    async editarInfo(nombre: string, apellidos: string, email: string, id: Number): Promise<void> {
        const query = `UPDATE usuarios SET nombre = '${nombre}', apellidos = '${apellidos}', email = '${email}' WHERE id_usuario = ${id}`
        await executeQuery(query)
    }

    async cambiarPassword(newPasswordHash: string, id: Number): Promise<void> {
        const query = `UPDATE usuarios SET password_hash = '${newPasswordHash}' WHERE id_usuario = ${id}`
        await executeQuery(query)
    }

    async cambiarPlan(plan: string, id: Number): Promise<void> {
        const planDB = plan === 'pro_anual' ? 'pro' : plan === 'gratis' ? 'free' : plan
        const existe = await executeQuery(`SELECT id_subscripcion FROM subscripcion WHERE id_usuario = $1`, [id])
        if (existe && existe.length > 0) {
            await executeQuery(`UPDATE subscripcion SET plan = $1, estado = 'activa' WHERE id_usuario = $2`, [planDB, id])
        } else {
            const inicio = new Date()
            const fin = new Date(inicio)
            fin.setMonth(fin.getMonth() + (plan === 'pro_anual' ? 12 : 1))
            await executeQuery(
                `INSERT INTO subscripcion (id_usuario, plan, estado, inicio_periodo, final_periodo) VALUES ($1, $2, 'activa', $3, $4)`,
                [id, planDB, inicio, fin]
            )
        }
    }
    async contarDocsMes(idUsuario : Number):Promise<Number> {
        const query = ` SELECT COUNT(*) AS total FROM documentos d
        JOIN chats c ON d.id_mensaje= (SELECT id_chat FROM mensajes WHERE id_mensaje= d.id_mensaje)
        WHERE c.id_usuario = ${idUsuario}
        AND date_trunc('month', d.creado_en) = date_trunc('month', NOW()); `;

        const result = await executeQuery(query);
        
        return Number(result[0].total);
    }
    async insertarMensaje(mensaje:Mensaje){
        const query=`INSERT INTO mensajes (id_chat, rol, contenido) VALUES ('${mensaje.idChat}', '${mensaje.rol}', '${mensaje.contenido}')`
        const rows: any[] = await executeQuery(query);
        if (!rows) {
            throw new Error("Error guardando el mensaje");
        }
    }
    async insertarDoc( documento:Mensaje, key:string) {
        await this.insertarMensaje(documento)
        const query=`INSERT INTO documentos (id_mensaje, s3_key, tipo) VALUES ('${documento.id}', '${key}', '${documento.tipoDoc}')`
        const rows: any[] = await executeQuery(query);
        if (!rows) {
            throw new Error("Error guardando el documento");
        }
    }
    async editarPrefencias(preferencias:any, id:Number):Promise<void> {
        const query = `UPDATE usuarios SET preferencias = $1::jsonb WHERE id_usuario = $2`
        await executeQuery(query, [JSON.stringify(preferencias ?? {}), id])
    }
    async login(usuario: Usuario): Promise<Usuario | null> {
        const query = `SELECT * FROM usuarios WHERE email = '${usuario.email}'`;

        const result: any[] = await executeQuery(query);
        if (!result || result.length === 0) {
            return null;
        }
        const row = result[0];
        
        const usuarioDB: Usuario = {
            email: row.email,
            password: row.password_hash,
            id: row.id_usuario,
            nombre: row.nombre,
            rol: row.rol,
            preferencias: row.preferencias
        };
        return usuarioDB;
    }
    async registro(usuario: Usuario): Promise<Usuario> {
        const preferenciasJson = JSON.stringify(usuario.preferencias);
        const query = `INSERT INTO usuarios (email, password_hash, nombre, apellidos, rol, preferencias) 
        VALUES ('${usuario.email}', '${usuario.password}', '${usuario.nombre}', '${usuario.apellidos}', '${usuario.rol}', '${preferenciasJson}')
        RETURNING *`;
        
        const result = await executeQuery(query);

        if (!result || result.length === 0) {
            throw new Error("Error guardando usuario");
        }

        const row = result[0];
        
        const usuarioDB: Usuario = {
            email: row.email,
            password: row.password_hash,
            id: row.id_usuario,
            nombre: row.nombre,
            rol: row.rol,
            preferencias: row.preferencias
        };
        return usuarioDB;
    }

}